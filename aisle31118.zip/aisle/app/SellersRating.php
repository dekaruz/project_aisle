<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SellersRating extends Model
{
    //
    protected $fillable = [
        'name'
    ];
}
