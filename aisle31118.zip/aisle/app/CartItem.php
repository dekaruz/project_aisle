<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Cart_item extends Model
{
    //
    protected $fillable = [
        'name'
    ];
}
