<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SellerProductDeliveryTime extends Model
{
    //
    protected $fillable = [
        'name'
    ];
}
