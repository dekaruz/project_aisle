<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>try</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="_token" content="{{ csrf_token() }}">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
    <link rel="stylesheet" type="text/css" media="screen" href="main.css" />

    <script></script>
</head>
<body>
<input type="text" class="form-controller" id="search" name="search"></input>
 <div class='d'></div>
</body>
<script src="{{asset('js/main.js')}}"></script>
</html>